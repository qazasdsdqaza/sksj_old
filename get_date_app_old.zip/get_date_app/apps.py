from django.apps import AppConfig


class GetDateAppConfig(AppConfig):
    name = 'get_date_app'
